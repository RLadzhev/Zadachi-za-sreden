﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            CalculateSV calculateSV = new CalculateSV();
            Console.Write("Vuvedi Radius:");
            calculateSV.Radius=double.Parse(Console.ReadLine());
            Console.Write("Vuvedi Visochina:");
            calculateSV.Visochina=double.Parse(Console.ReadLine());
            calculateSV.CalculatePulnaPovurhnina();
            calculateSV.CalculateObem();
        }
    }
}
